from PIL import Image, ImageDraw

L = 96
output_path = "Down Tap Explosion bright (res 96x96).png"
input_path = "original down tap explosion bright.png"

def get_alpha_pixels(path): 
    img = Image.open(path).convert("RGBA")
    _,_,_, alpha = img.split()
    alpha = alpha.convert("L")
    pixels = alpha.load()
    return img, alpha, pixels

mask, mask_alpha, mask_pixels = get_alpha_pixels("mask_clean.png")
img, img_alpha, img_pixels = get_alpha_pixels(input_path)

for x in range(L): 
    for y in range(L): 
        if mask_pixels[x,y] != 0: 
            img_pixels[x,y] = 0

img.putalpha(img_alpha)
img.save(output_path)


