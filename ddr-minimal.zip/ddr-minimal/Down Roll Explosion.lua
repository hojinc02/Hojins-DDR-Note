local t = Def.ActorFrame {
	Def.Sprite {
		--Texture=NOTESKIN:GetPath( 'Down', 'Hold Explosion' );
		Texture=NOTESKIN:GetPath( 'Down', 'Tap Explosion Dim' );
	};
};
return t;
